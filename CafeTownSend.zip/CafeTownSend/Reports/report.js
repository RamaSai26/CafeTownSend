$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("CafeTownSend.feature");
formatter.feature({
  "line": 1,
  "name": "CafeTownSend",
  "description": "",
  "id": "cafetownsend",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 6,
  "name": "Login with invalid credentials",
  "description": "",
  "id": "cafetownsend;login-with-invalid-credentials",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 5,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "User is on Home Page",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "User enters \"\u003cusername\u003e\" and \"\u003cpassword\u003e\" to LogIn",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "User not logged in",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "Close Browser",
  "keyword": "And "
});
formatter.examples({
  "line": 11,
  "name": "",
  "description": "",
  "id": "cafetownsend;login-with-invalid-credentials;",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ],
      "line": 12,
      "id": "cafetownsend;login-with-invalid-credentials;;1"
    },
    {
      "cells": [
        "wrong",
        "Skywalker"
      ],
      "line": 13,
      "id": "cafetownsend;login-with-invalid-credentials;;2"
    },
    {
      "cells": [
        "Luke",
        "wrong"
      ],
      "line": 14,
      "id": "cafetownsend;login-with-invalid-credentials;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 13,
  "name": "Login with invalid credentials",
  "description": "",
  "id": "cafetownsend;login-with-invalid-credentials;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 5,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "User is on Home Page",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "User enters \"wrong\" and \"Skywalker\" to LogIn",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "User not logged in",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "Close Browser",
  "keyword": "And "
});
formatter.match({
  "location": "TestSteps.user_is_on_Home_Page()"
});
formatter.result({
  "duration": 4806325484,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "wrong",
      "offset": 13
    },
    {
      "val": "Skywalker",
      "offset": 25
    }
  ],
  "location": "TestSteps.user_enters_credentials(String,String)"
});
formatter.result({
  "duration": 5447109756,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_not_loggedin()"
});
formatter.result({
  "duration": 617613962,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.close_browser()"
});
formatter.result({
  "duration": 50797299,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Login with invalid credentials",
  "description": "",
  "id": "cafetownsend;login-with-invalid-credentials;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 5,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "User is on Home Page",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "User enters \"Luke\" and \"wrong\" to LogIn",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "User not logged in",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "Close Browser",
  "keyword": "And "
});
formatter.match({
  "location": "TestSteps.user_is_on_Home_Page()"
});
formatter.result({
  "duration": 3502259630,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Luke",
      "offset": 13
    },
    {
      "val": "wrong",
      "offset": 24
    }
  ],
  "location": "TestSteps.user_enters_credentials(String,String)"
});
formatter.result({
  "duration": 5441334957,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_not_loggedin()"
});
formatter.result({
  "duration": 615095488,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.close_browser()"
});
formatter.result({
  "duration": 51439576,
  "status": "passed"
});
formatter.scenario({
  "comments": [
    {
      "line": 15,
      "value": "#    | testuser1 | \t\t\t |"
    },
    {
      "line": 16,
      "value": "#    |\t\t\t | Puppy@1      |"
    }
  ],
  "line": 19,
  "name": "Successful Login with Valid Credentials",
  "description": "",
  "id": "cafetownsend;successful-login-with-valid-credentials",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 18,
      "name": "@tag2"
    }
  ]
});
formatter.step({
  "line": 20,
  "name": "User is on Home Page",
  "keyword": "Given "
});
formatter.step({
  "line": 21,
  "name": "User enters Credentials to LogIn",
  "rows": [
    {
      "cells": [
        "Luke",
        "Skywalker"
      ],
      "line": 22
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "User Logged in Successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "TestSteps.user_is_on_Home_Page()"
});
formatter.result({
  "duration": 4367230816,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_enters_testuser_and_Test(DataTable)"
});
formatter.result({
  "duration": 379929571,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.User_logged_in()"
});
formatter.result({
  "duration": 49157190,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Click to view and Update User details",
  "description": "",
  "id": "cafetownsend;click-to-view-and-update-user-details",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 25,
      "name": "@tag3"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "User Logged in Successfully",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "User clicks on any user",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "User is able to update user details",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "Clicks on Update button",
  "keyword": "Then "
});
formatter.match({
  "location": "TestSteps.User_logged_in()"
});
formatter.result({
  "duration": 33474039,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.User_clicks_on_any_user()"
});
formatter.result({
  "duration": 1027690137,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.User_Updates_details()"
});
formatter.result({
  "duration": 146607427,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_clicks_Update()"
});
formatter.result({
  "duration": 536576194,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "Click on Create and Add user",
  "description": "",
  "id": "cafetownsend;click-on-create-and-add-user",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 33,
      "name": "@tag4"
    }
  ]
});
formatter.step({
  "line": 35,
  "name": "User Logged in Successfully",
  "keyword": "Given "
});
formatter.step({
  "line": 36,
  "name": "User clicks on Create button",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "adds user details and clicks Add",
  "keyword": "And "
});
formatter.step({
  "line": 38,
  "name": "The user is added to User list",
  "keyword": "Then "
});
formatter.match({
  "location": "TestSteps.User_logged_in()"
});
formatter.result({
  "duration": 38009227,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.User_Clicks_create()"
});
formatter.result({
  "duration": 105587066,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_details()"
});
formatter.result({
  "duration": 608444030,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_added()"
});
formatter.result({
  "duration": 17313020,
  "status": "passed"
});
});