package StepDefinitions;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.http.ExceptionLogger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import CafeTownSendTest.UtilityClass;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import StepDefinitions.Credentials;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentXReporter;
import com.aventstack.extentreports.reporter.KlovReporter;
import com.github.mkolisnyk.cucumber.reporting.CucumberUsageReporting;

 




public class TestSteps {
	
	
	public static WebDriver driver;
	UtilityClass utilObj;
	
	By eleMessage =  By.xpath("//*[@id=\"login-form\"]/fieldset/p[1]");
	By eleUsername = By.xpath("//*[@id=\"login-form\"]/fieldset/label[1]/input");
	By elePassword = By.xpath("//*[@id=\"login-form\"]/fieldset/label[2]/input");
	By eleLogin =   By.xpath("//*[@id=\"login-form\"]/fieldset/button");
	By eleWelcome = By.xpath("//*[@id=\"greetings\"]");
	//By eleUserList = By.cssSelector("#employee-list li:nth-of-type(4)");
	By eleUserinList=By.cssSelector("#employee-list li:nth-of-type(4)");
	By eleUpdate=By.xpath("//*[@name=\"employeeForm\"]/fieldset/div/button[1]");//cssSelector("input[name='employeeForm']fieldset>div>button");[ng-click='selectEmployee(employee)'][ng-hide='isCreateForm'][ng-disabled='false']
	By eleBack = By.cssSelector("#sub-nav > li > a");
	By eleCreate = By.cssSelector("#bAdd");
	By eleEmail = By.cssSelector("body > div > div > div > form > fieldset > label:nth-child(6) > input");
	By eleAdd = By.cssSelector("body > div > div > div > form > fieldset > div > button:nth-child(2)");
	
	By eleFirstName = By.cssSelector("body > div > div > div > form > fieldset > label:nth-child(3) > input");
	By eleLastName = By.xpath("/html/body/div/div/div/form/fieldset/label[2]/input");
	By eleStartDate = By.xpath("/html/body/div/div/div/form/fieldset/label[3]/input");
	By eleAddEmail = By.xpath("/html/body/div/div/div/form/fieldset/label[4]/input");
	
//	String extentReportFile = System.getProperty("user.dir")
//			+ "\\extentReportFile.html";
//	String extentReportImage = System.getProperty("user.dir")
//			+ "\\extentReportImage.png";
//
//	
			
		

			
			
	public void check() throws Exception
	{
		// start reporters
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("extent.html");
    
        // create ExtentReports and attach reporter(s)
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        // creates a toggle for the given test, adds all log events under it    
        ExtentTest test = extent.createTest("MyFirstTest", "Sample description");

        // log(Status, details)
        test.log(Status.INFO, "This step shows usage of log(status, details)");

        // info(details)
        test.info("This step shows usage of info(details)");
        
        // log with snapshot
        test.fail("details", MediaEntityBuilder.createScreenCaptureFromPath("screenshot.png").build());
        
        // test with snapshot
        test.addScreenCaptureFromPath("screenshot.png");
        
        // calling flush writes everything to the log file
        extent.flush();
	}
	
	@Given("^User is on Home Page$")
	public void user_is_on_Home_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","E:\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://cafetownsend-angular-rails.herokuapp.com/login");
        
		}
	
	
	@When("^User enters \"([^\"]*)\" and \"([^\"]*)\" to LogIn$")
	public void user_enters_credentials(String username, String password) throws Throwable{	
				
		driver.findElement(eleUsername).clear();
		Thread.sleep(5000);
        driver.findElement(eleUsername).sendKeys(username);
        driver.findElement(elePassword).clear();
        driver.findElement(elePassword).sendKeys(password);
        driver.findElement(eleLogin).click();
	}
	
	@Then("^User not logged in$")
	public void user_not_loggedin()
	{
		 WebDriverWait wait = new WebDriverWait(driver,40);
	     wait.until(ExpectedConditions.textToBePresentInElement(eleMessage,"Invalid username or password!"));
	     System.out.println(driver.findElement(eleMessage).getText());	     
	    Assert.assertEquals(driver.findElement(eleMessage).getText(), "Invalid username or password!"); 	 
	     
	}
	
	@Then("^Close Browser$")
	public void close_browser()
	{
		driver.close();
	}
	
	@When("^User enters Credentials to LogIn$")
	public void user_enters_testuser_and_Test(DataTable usercredentials) throws Throwable {

		//Write the code to handle Data Table
		List<List<String>> data = usercredentials.raw();
		driver.findElement(eleUsername).sendKeys(data.get(0).get(0)); 
	    driver.findElement(elePassword).sendKeys(data.get(0).get(1));
	    driver.findElement(eleLogin).click();
	}
	
	@Then("^User Logged in Successfully$")
	public void User_logged_in()
	{
		System.out.println(driver.findElement(eleWelcome).getText());
		Assert.assertEquals(driver.findElement(eleWelcome).getText(), "Hello Luke"); 
	}
	
	@When("^User clicks on any user$")
	public void User_clicks_on_any_user()
	{		
		WebElement element=driver.findElement(eleUserinList); 
		driver.findElement(eleUserinList).click();
		Actions action = new Actions(driver);		
		action.doubleClick(element).perform();
		element=driver.findElement(eleUpdate);
		Assert.assertEquals(element.getText(), "Update");
		
	}
	
	@When("^User is able to update user details$")
	public void User_Updates_details()
	{
		driver.findElement(eleEmail).clear();
		driver.findElement(eleEmail).sendKeys("abc@dgd.com");
		System.out.println(driver.findElement(eleEmail).getText());
	//	Assert.assertEquals(driver.findElement(eleEmail).getText(), "abc@dgd.com");
	}
	
	@Then("^Clicks on Update button$")
	public void user_clicks_Update()
	{
		driver.findElement(eleUpdate).click();
		Assert.assertEquals(driver.findElement(eleCreate).isDisplayed(),true);
	}
	
	@When("^User clicks on Create button$")
	public void User_Clicks_create()  ///Clicks on create button in the main page
	{
		driver.findElement(eleCreate).click();
		Assert.assertEquals(driver.findElement(eleAdd).isDisplayed(),true);
	}
	@When("^adds user details and clicks Add$")
	public void user_details()
	{
		driver.findElement(eleFirstName).sendKeys("Pea");
		driver.findElement(eleLastName).sendKeys("Cock");
		driver.findElement(eleStartDate).sendKeys("1990-03-24");
		driver.findElement(eleAddEmail).sendKeys("start@end.com");
		driver.findElement(eleAdd).click();
		Assert.assertEquals(driver.findElement(eleCreate).isDisplayed(),true);
	}
	
	@Then("^The user is added to User list$")
	public void user_added()
	{
		Assert.assertEquals(driver.findElement(eleCreate).isDisplayed(),true);
	}
	
	@Then("^User navigates back to all users$")
	public void user_navigates_back_to_all_users() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(eleBack).click();
		Assert.assertEquals(driver.findElement(eleCreate).isDisplayed(),true);
	}
	
//	@Given("^Create reports$")
//	public void create_reports()
//	{
//		
//	}

}
