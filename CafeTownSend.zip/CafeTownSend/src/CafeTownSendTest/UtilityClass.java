package CafeTownSendTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class UtilityClass {
	WebDriver driver;
	
	public UtilityClass(WebDriver driver)
	{
		this.driver = driver;
	}
	public void setText(Object element,String strTobeSet)
	{
		driver.findElement((By) element).clear();
        driver.findElement((By) element).sendKeys(strTobeSet);
	}
	
	public void clkButton(Object element)
	{
		driver.findElement((By) element).click();
	}
	

}
