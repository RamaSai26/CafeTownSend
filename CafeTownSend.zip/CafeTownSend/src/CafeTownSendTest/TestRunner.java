package CafeTownSendTest;


import org.junit.AfterClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.github.mkolisnyk.cucumber.reporting.CucumberResultsOverview;
import com.github.mkolisnyk.cucumber.reporting.CucumberUsageReporting;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Feature"
		,glue={"StepDefinitions"}
		,monochrome=true
		//,plugin = { "pretty","html:Reports/cucumber-reports"}//"json:Reports/cucumber-reports" },
		,plugin = { "pretty", "json:Reports/cucumber-reports/Cucumber.json",
				"junit:Reports/cucumber-reports/Cucumber.xml",
				"html:Reports/cucumber-reports"}
		//,tags= {"@tag1"}//,
		//dryRun=true
		)

public class TestRunner {
	
	//@AfterClass
	public static void main(String[] args) throws Exception {
		CucumberResultsOverview results = new CucumberResultsOverview();
		results.setOutputDirectory("target");
		results.setOutputName("cucumber-results");
		results.setSourceFile("Reports/cucumber-reports/Cucumber.json");
		results.executeFeaturesOverviewReport();
	}
}